function addTask() {
    const taskInput = document.getElementById('taskInput');
    const taskList = document.getElementById('taskList');
    const todosCount = document.getElementById('todosCount');

    const taskText = taskInput.value.trim();
    if (taskText !== '') {
        const taskItem = document.createElement('li');
        taskItem.innerHTML = `
            <span>${taskText}</span>
            <div class="todo-buttons">
                <button class="modify" onclick="modifyTask(this)">Modify</button>
                <button class="done" onclick="toggleCompletion(this)">Done</button>
                <button class="delete" onclick="deleteTask(this)">Delete</button>
            </div>
        `;
        taskList.appendChild(taskItem);

        // Update todos count
        todosCount.textContent = parseInt(todosCount.textContent) + 1;

        // Clear the input for the next task
        taskInput.value = '';
    }
}

function toggleCompletion(button) {
    const taskItem = button.closest('li');
    const taskText = taskItem.querySelector('span');
    taskText.classList.toggle('completed');
}

function modifyTask(button) {
    const taskItem = button.closest('li');
    const taskText = taskItem.querySelector('span');
    const newTaskText = prompt('Modify the task:', taskText.textContent);
    if (newTaskText !== null) {
        taskText.textContent = newTaskText;
    }
}

function deleteTask(button) {
    const taskItem = button.closest('li');
    taskItem.remove();

    // Update todos count
    const todosCount = document.getElementById('todosCount');
    todosCount.textContent = Math.max(0, parseInt(todosCount.textContent) - 1);
}
